#pragma once
#ifndef MAINHEADERS
#define MAINHEADERS

#include "comdef.h"
#include "../Simurosot/skills.h"
#include "../Simurosot/Utils/kalman.h"
#include "../Simurosot/common/include/config.h"
#include "../Simurosot/includes.h"
#include "../SimuroSot/Utils/pathPlanners.h"
#include "../SimuroSot/Core/beliefState.h"
#endif