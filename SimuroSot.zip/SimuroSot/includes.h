#include "Game.hpp"

// Examples
#include "Attacker.hpp"
#include "Defender.hpp"
#include "GoalKeeper.hpp"